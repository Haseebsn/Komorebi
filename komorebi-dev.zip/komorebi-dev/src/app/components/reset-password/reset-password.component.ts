import { User } from './../../models/user';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css'],
})
export class ResetPasswordComponent {
  userSession: User = new User();
  username: string = '';
  usernameErr: string = '';
  password: string = '';
  passwordErr: string = '';
  msg: string = '';
  verifiedUser: boolean = false;

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'reset';
  }

  back(): void {
    this.router.navigateByUrl('/login');
  }

  verifyUser(): void {
    if (this.util.isNotNullOrEmptyOrUndefined(this.username))
      this.commonService.verifyUser(this.username).subscribe((response) => {
        if (response.success) this.verifiedUser = true;
        else this.usernameErr = response.error;
      });
  }

  resetPassword(): void {
    if (this.util.isNotNullOrEmptyOrUndefined(this.password))
      this.commonService
        .resetPassword(this.username, this.password)
        .subscribe((response) => {
          if (response.success)  {
            this.msg = 'Password reset successfully';
            this.username = '';
            this.password = '';
          }
          else this.passwordErr = response.error;
        });
  }
}
