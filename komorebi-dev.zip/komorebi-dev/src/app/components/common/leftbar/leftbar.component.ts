import { UtilService } from './../../../services/util.service';
import { CommonService } from './../../../services/common.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-leftbar',
  templateUrl: './leftbar.component.html',
  styleUrls: ['./leftbar.component.css'],
})
export class LeftbarComponent implements OnInit {
  allowedActive: string[] = ['login', 'signup', 'reset'];
  userSession: User = new User();
  docCount: number = 0;

  constructor(private commonService: CommonService, private util: UtilService) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {}

  get getActiveComponent(): string {
    return this.commonService.activeComponent;
  }

  getDocCount(): number {
    return Number(this.commonService.docCount);
  }
}
