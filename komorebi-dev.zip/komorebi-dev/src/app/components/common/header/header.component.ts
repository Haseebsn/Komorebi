import { User } from 'src/app/models/user';
import { CommonService } from './../../../services/common.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css'],
})
export class HeaderComponent implements OnInit {
  allowedActive: string[] = ['login', 'signup', 'reset'];
  userSession: User = new User();

  constructor(private commonService: CommonService, private router: Router) {}

  ngOnInit(): void {
    this.userSession = this.commonService.getUserSession();
  }

  get getActiveComponent(): string {
    return this.commonService.activeComponent;
  }

  logout(): void {
    if (this.commonService.clearSession()) this.router.navigateByUrl('/login');
  }
}
