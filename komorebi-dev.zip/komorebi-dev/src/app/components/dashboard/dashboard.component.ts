import { User } from './../../models/user';
import { UtilService } from './../../services/util.service';
import { CommonService } from './../../services/common.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  orgCount: number = 0;
  studentCount: number = 0;
  jobCount: number = 0;
  contactCount: number = 0;

  constructor(
    private commonService: CommonService,
    private util: UtilService
  ) {}

  ngOnInit(): void {
    this.commonService.activeComponent = 'dashboard';

    this.commonService.getOrganizations().subscribe((response) => {
      this.orgCount = response.data.orgCount;
    });

    this.commonService.getStudents().subscribe((response) => {
      this.studentCount = response.data.stdcount;
    });

    this.commonService.getJobs().subscribe((response) => {
      this.jobCount = response.data.jobsCount;
    });

    // this.commonService.getContacts().subscribe((response) => {
    //   console.log(response);
    //   this.contactCount = response.data;
    // });
  }
}
