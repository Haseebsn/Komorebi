import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-organizations',
  templateUrl: './organizations.component.html',
  styleUrls: ['./organizations.component.css'],
})
export class OrganizationsComponent implements OnInit {
  userSession: User = new User();
  orgList: any[] = [];
  orgData: any = {};
  orgDataErr: any = {};
  isAddOrg: boolean = false;
  orgAction: string | null = '';
  orgActionId: number | undefined = undefined;

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');

    commonService.activeComponent = 'organizations';
  }

  ngOnInit(): void {
    this.commonService.fetchAllOrganizations().subscribe((response) => {
      this.orgList = response.data;
    });

    if (
      this.route.snapshot.paramMap.has('action') &&
      this.route.snapshot.paramMap.has('id')
    ) {
      this.orgAction = this.route.snapshot.paramMap.get('action');
      this.orgActionId = Number(this.route.snapshot.paramMap.get('id'));

      if (this.orgAction == 'edit')
        this.commonService
          .fetchUserById(this.orgActionId)
          .subscribe((response) => {
            this.isAddOrg = true;
            this.orgData = response.data[0];
          });

      if (this.orgAction == 'delete')
        this.commonService
          .deleteUserById(this.orgActionId)
          .subscribe((response) => {
            if (response.success) {
              this.orgDataErr.delete = 1;
              this.router.navigateByUrl('/organization');
            }
          });
    }
  }

  clear(): void {
    this.orgData = {};
    this.orgAction = '';
    this.orgActionId = undefined;
  }

  toggleAddOrganization(): void {
    this.isAddOrg = !this.isAddOrg;
    this.orgAction = '';
    this.orgActionId = undefined;
  }

  validateOrgData(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.orgData.name)) {
      validated = false;
      this.orgDataErr.name = 'Name is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.orgData.email)) {
      validated = false;
      this.orgDataErr.email = 'Email is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.orgData.password)) {
      validated = false;
      this.orgDataErr.password = 'Password is mandatory';
    }

    return validated;
  }

  addOrganization(): void {
    if (this.validateOrgData()) {
      this.orgData.updatedBy = Number(this.userSession.id);
      this.orgData.updatedOn = new Date();

      if (this.util.isNullOrEmptyOrUndefined(this.orgActionId)) {
        this.orgData.username = this.orgData.email;
        this.orgData.category = 'organization';
        this.orgData.orgId = Number(this.userSession.id);
        this.orgData.createdBy = Number(this.userSession.id);
        this.orgData.createdOn = new Date();

        this.commonService.signup(this.orgData).subscribe((response) => {
          if (response.success) {
            this.orgDataErr.add = 'Organization added successfully';
            this.clear();
          } else this.orgDataErr.addErr = response.error;
        });
      } else
        this.commonService.updateUser(this.orgData).subscribe((response) => {
          if (response.success) {
            this.orgDataErr.add = 'Organization updated successfully';
            this.router.navigateByUrl('/organization');
          } else this.orgDataErr.addErr = response.error;
        });
    }
  }
}
