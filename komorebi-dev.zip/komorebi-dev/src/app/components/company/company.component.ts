import { User } from 'src/app/models/user';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrls: ['./company.component.css'],
})
export class CompanyComponent implements OnInit {
  userSession: User = new User();
  companyId?: number;
  companyData: any = {};
  companyErr: any = {};
  companyDocList: any[] = [];
  isRating: boolean = false;
  companyRating: number = 2;
  rating?: number;
  review: string = '';
  ratingErr: any = {};

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'company';

    if (this.route.snapshot.paramMap.has('id')) {
      this.companyId = Number(this.route.snapshot.paramMap.get('id'));

      if (this.util.isNotNullOrEmptyOrUndefined(this.companyId)) {
        this.commonService
          .fetchUserById(this.companyId)
          .subscribe((response) => {
            if (response.success) this.companyData = response.data[0];
            else this.companyErr = response.error;
          });

        this.commonService
          .fetchCompanyRating(this.companyId)
          .subscribe((response) => {
            let ratings: any = [];
            if (response.success) ratings = response.data;
            else this.companyErr.rateErr = response.error;

            if (this.util.isNotNullOrEmptyOrUndefined(ratings)) {
              let totalRating = 0;
              ratings.forEach((rate: any) => {
                totalRating += rate.rating;
              });

              this.companyRating = Math.floor(totalRating / ratings.length);
            }
          });

        this.commonService
          .fetchDocumentListOfOrg(Number(this.companyId))
          .subscribe((response) => {
            if (response.success) {
              this.companyDocList = response.data;
            } else this.companyErr.docErr = response.error;
          });
      }
    }
  }

  toggleBackRating(): void {
    this.router.navigateByUrl('/company/' + this.companyId);
  }

  rateCompany(): void {
    this.isRating = !this.isRating;
  }

  submitRating(): void {
    if (
      this.util.isNotNullOrEmptyOrUndefined(this.rating) &&
      this.util.isNotNullOrEmptyOrUndefined(this.review)
    ) {
      let ratingData: any = {};

      ratingData.rating = Number(this.rating);
      ratingData.review = this.review;
      ratingData.ratedBy = Number(this.userSession.id);
      ratingData.ratedTo = this.companyId;

      this.commonService.rateCompany(ratingData).subscribe((response) => {
        if (response.success) {
          this.ratingErr.rate = 'Rating has been submitted';
          this.review = '';
          this.rating = undefined;
        } else this.ratingErr.rateErr = response.error;
      });
    }
  }

  closeMsg(): void {
    this.ratingErr.rate = null;
    this.ratingErr.rateErr = null;
  }
}
