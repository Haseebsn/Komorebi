import { User } from './../../models/user';
import { Component } from '@angular/core';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-password',
  templateUrl: './password.component.html',
  styleUrls: ['./password.component.css'],
})
export class PasswordComponent {
  userSession: User = new User();
  oldPassword: string = '';
  newPassword: string = '';
  confirmPassword: string = '';
  passwordErr: string = '';
  msg: string = '';

  constructor(
    private commonService: CommonService,
    private util: UtilService,
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'students';
  }

  closeMsg(wrapper: string): void {
    if (wrapper == 'err') this.passwordErr = '';
    if (wrapper == 'success') this.msg = '';
  }

  validatePassword(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.oldPassword)) {
      validated = false;
      this.passwordErr = 'Enter old password';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.newPassword)) {
      validated = false;
      this.passwordErr = 'Enter new password';
    }

    return validated;
  }

  savePassword(): void {
    if (this.validatePassword()) {
      let pwdData: any = {};

      pwdData.uid = this.userSession.id;
      pwdData.old = this.oldPassword;
      pwdData.new = this.newPassword;

      this.commonService.changePassword(pwdData).subscribe((response) => {
        if (response.success) {
          this.msg = 'Password changed successfully';
          this.oldPassword = '';
          this.newPassword = '';
          this.confirmPassword = '';
        } 
        else this.passwordErr = response.error;
      });
    }
  }
}
