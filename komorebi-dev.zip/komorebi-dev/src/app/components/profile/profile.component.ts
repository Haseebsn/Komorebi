import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent {
  userSession: User = new User();
  profileData: User = new User();
  profileDataErr: any = {};
  profileAction: string | null = '';
  profileActionId: number | undefined = undefined;

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'profile';

    this.commonService
      .fetchUserById(Number(this.userSession.id))
      .subscribe((response) => {
        if (response.success) this.profileData = response.data[0];
        else this.profileDataErr.addErr = response.error;
      });
  }

  closeMsg(wrapper: string): void {
    if(wrapper == 'addErr') this.profileDataErr.addErr = null;
    if(wrapper == 'add') this.profileDataErr.add = null;
  }

  validateProfileData(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.profileData.name)) {
      validated = false;
      this.profileDataErr.name = 'Name is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.profileData.email)) {
      validated = false;
      this.profileDataErr.email = 'Email is mandatory';
    }

    return validated;
  }

  updateProfile(): void {
    this.profileDataErr = {};

    if (this.validateProfileData())
      this.commonService.updateUser(this.profileData).subscribe((response) => {
        if (response.success) {
          this.profileDataErr.add = 'Profile updated successfully';
        } else this.profileDataErr.addErr = response.error;
      });
  }
}
