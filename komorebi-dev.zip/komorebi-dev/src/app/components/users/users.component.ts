import { AfterViewInit, Component, OnInit } from '@angular/core';
import { interval } from 'rxjs';
import { User } from 'src/app/models/user';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css'],
})
export class UsersComponent implements OnInit, AfterViewInit {
  userSession: User = new User();
  userChats: any[] = [];
  chatNames: any[] = [];
  openedChatMessages: any[] = [];
  openedChatUserId: number = 0;
  msgToSend: string = '';
  inboxErr: any = {};
  msgSent: boolean = false;
  constructor(private commonService: CommonService, private util: UtilService) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'inbox';

    this.fetchAllChats();
  }

  ngAfterViewInit(): void {
    interval(3000).subscribe((val) => {
      this.refreshChat;
    });
  }

  closeMsg(): void {
    this.msgSent = false;
  }

  fetchAllChats(): void {
    this.commonService
      .fetchAllChats(Number(this.userSession.id))
      .subscribe((response) => {
        if (response.success) {
          this.userChats = response.data;

          this.userChats.forEach((chat) => {
            if (!this.checkChatExist(chat))
              this.chatNames.push({ name: chat.sender, id: chat.msgFrom });
          });
        } else this.inboxErr.error = response.error;
      });
  }

  checkChatExist(chat: any): boolean {
    let isExist: boolean = false;
    this.chatNames.forEach((chatname) => {
      if (
        (chatname.name == chat.sender || chatname.name == chat.receiver) &&
        (this.userSession.id != chat.msgFrom || this.userSession != chat.msgTo)
      )
        isExist = true;
    });

    return isExist;
  }

  openChat(of: number) {
    this.openedChatUserId = of;
    this.openedChatMessages = [];
    this.userChats.forEach((chat) => {
      if (chat.msgFrom == of || chat.msgTo == of)
        this.openedChatMessages.push(chat);
    });
  }

  sendMessage(): void {
    let msg: any = {};

    msg.f = this.userSession.id;
    msg.t = this.openedChatUserId;
    msg.msg = this.msgToSend;

    this.commonService.sendMessage(msg).subscribe((response) => {
      if (response.success) {
        this.msgSent = true;
        this.msgToSend = '';
      } else this.inboxErr.msg = response.error;
    });
  }

  get refreshChat(): boolean {
    this.commonService
      .fetchAllChats(Number(this.userSession.id))
      .subscribe((response) => {
        if (response.success) {
          this.userChats = response.data;

          this.userChats.forEach((chat) => {
            if (!this.checkChatExist(chat))
              this.chatNames.push({ name: chat.sender, id: chat.msgFrom });
          });

          if (
            this.util.isNotNullOrEmptyOrUndefined(this.openedChatUserId) ||
            this.openedChatUserId > 0
          )
            this.openChat(this.openedChatUserId);
        } else this.inboxErr.error = response.error;
      });

    return true;
  }
}
