import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { User } from 'src/app/models/user';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-student-dashboard',
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.css'],
})
export class StudentDashboardComponent implements OnInit {
  userSession: User = new User();
  jobsData: any = {};
  jobsDataErr: any = {};
  isAddJobs: boolean = false;
  jobsList: any[] = [];
  docList: any[] = [];
  jobsAction: string | null = '';
  jobsActionId: number | undefined = undefined;
  selectedFiles: File[] = [];
  fileInfos: any[] = [];
  fileCount: number = 0;
  isUploading: boolean = false;
  uploadedFileCount: number = -1;
  cdn: string = 'http://localhost:3000/';

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'jobs';

    this.fetchAllJobs();

    this.fetchDocList(this.userSession.id);

    if (
      this.route.snapshot.paramMap.has('action') ||
      this.route.snapshot.paramMap.has('id')
    ) {
      this.jobsAction = this.route.snapshot.paramMap.get('action');
      this.jobsActionId = Number(this.route.snapshot.paramMap.get('id'));

      if (this.jobsAction == 'edit')
        this.commonService
          .fetchJobById(this.jobsActionId)
          .subscribe((response) => {
            this.isAddJobs = true;
            this.jobsData = response.data[0];
          });

      if (this.jobsAction == 'delete')
        this.commonService
          .deleteJobById(this.jobsActionId)
          .subscribe((response) => {
            if (response.success) {
              this.jobsDataErr.delete = 1;
              this.router.navigateByUrl('/dashboard/student');
            }
          });

      if (this.jobsAction == 'view')
        this.commonService
          .fetchJobById(this.jobsActionId)
          .subscribe((response) => {
            if (response.success) this.jobsData = response.data[0];
            else this.jobsDataErr.view = response.error;
          });
    }
  }

  clear(): void {
    this.jobsAction = '';
    this.jobsActionId = undefined;
    this.jobsData = {};
    this.jobsDataErr = {};
    this.isAddJobs = false;
  }

  toggleAddJobs(): void {
    this.isAddJobs = !this.isAddJobs;

    if (this.jobsAction != '') this.router.navigateByUrl('/dashboard/student');
  }

  fetchAllJobs(): void {
    if (this.userSession.category == 'organization')
      this.commonService
        .fetchJobsByOrgId(this.userSession.id)
        .subscribe((response) => {
          this.jobsList = response.data;
        });
    else
      this.commonService.fetchAllJobs().subscribe((response) => {
        this.jobsList = response.data;
      });
  }

  fetchDocList(id: number | undefined) {
    this.docList = [];
    if (this.util.isNotNullOrEmptyOrUndefined(id)) {
      this.commonService.fetchDocumentList(id).subscribe((response) => {
        if (response.success) {
          this.docList = response.data;
          this.commonService.docCount = response.data.length;
        } else this.jobsDataErr.docErr = response.error;
      });
    }
  }

  applyJob(jobId: number): void {
    let applicationData: any = {};

    applicationData.jobId = jobId;
    applicationData.applicantId = this.userSession.id;

    this.jobsDataErr = {};
    
    this.commonService.applyJob(applicationData).subscribe((response) => {
      if (response.success) this.jobsDataErr.view = 'Applied successfully';
      else this.jobsDataErr.viewErr = response.error;
    });
  }

  selectFiles(event: any): void {
    this.fileCount = this.uploadedFileCount = 0;
    this.selectedFiles = event.target.files;
    this.fileCount = this.selectedFiles.length;
  }

  async uploadFiles(requestId: number) {
    this.fileInfos = [];
    this.uploadedFileCount = 0;
    this.isUploading = true;
    for (let i = 0; i < this.selectedFiles.length; i++) {
      let file = this.selectedFiles[i];

      try {
        const convertedFile = await this.fileToBase64(file);

        let fileData: any = {};

        fileData.requestId = requestId;
        fileData.file = convertedFile;
        fileData.fileName = file.name.split('.')[0];
        fileData.fileType = file.type;
        fileData.createdBy = this.userSession.id;
        fileData.updatedBy = this.userSession.id;

        this.commonService.uploadDocument(fileData).subscribe((response) => {
          if (i + 1 == this.fileCount) this.isUploading = false;
          if (response.success) {
            this.fileInfos[i] = response.data;
            this.uploadedFileCount++;
          } else
            this.jobsDataErr.docErr =
              'Error uploading file ' + (i + 1) + ' : ' + response.error;
        });
      } catch (error) {
        console.error(error);
        return;
      }
    }
  }

  fileToBase64 = (file: File) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = (error) => reject(error);
    });

  validateJobData(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.jobsData.jobId)) {
      validated = false;
      this.jobsDataErr.jobId = 'Job id is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.jobsData.title)) {
      validated = false;
      this.jobsDataErr.title = 'Title is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.jobsData.description)) {
      validated = false;
      this.jobsDataErr.description = 'Description is mandatory';
    }

    return validated;
  }

  addJob(): void {
    if (this.validateJobData()) {
      this.jobsData.orgId = this.userSession.id;
      this.jobsData.updatedBy = Number(this.userSession.id);
      this.jobsData.updatedOn = new Date();

      if (this.util.isNullOrEmptyOrUndefined(this.jobsActionId)) {
        this.jobsData.createdBy = Number(this.userSession.id);
        this.jobsData.createdOn = new Date();

        this.commonService.createJob(this.jobsData).subscribe((response) => {
          if (response.success) {
            this.jobsDataErr.add = 'Job added successfully';
            this.fetchAllJobs();
            this.clear();
          } else this.jobsDataErr.addErr = response.error;
        });
      } else
        this.commonService.updateJob(this.jobsData).subscribe((response) => {
          if (response.success) {
            this.jobsDataErr.add = 'jobs updated successfully';
          } else this.jobsDataErr.addErr = response.error;
          this.router.navigateByUrl('/dashboard/student');
        });
    }
  }
}
