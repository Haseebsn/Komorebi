import { AuthService } from './../../services/auth.service';
import { CommonService } from './../../services/common.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as moment from 'moment';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  username: string = '';
  password: string = '';
  usernameErr: string = '';
  passwordErr: string = '';
  loginErr: string = '';

  constructor(
    private commonService: CommonService,
    private auth: AuthService,
    private router: Router
  ) {
    commonService.activeComponent = 'login';
  }

  ngOnInit(): void {}

  authenticate(): void {
    if (
      this.username == '' ||
      this.username == null ||
      this.username == undefined
    )
      this.usernameErr = 'Enter username';

    if (
      this.password == '' ||
      this.password == null ||
      this.password == undefined
    )
      this.passwordErr = 'Enter password';

    if (this.usernameErr == '' && this.passwordErr == '')
      this.commonService
        .authenticate(this.username, this.password)
        .subscribe((response) => {
          if (response.success) {
            let user = this.commonService.setUserSession(response.data.token);

            if (user.category == 'admin')
              this.router.navigateByUrl('/dashboard');
            else if (user.category == 'organization')
              this.router.navigateByUrl('/students');
            else if (user.category == 'student')
              this.router.navigateByUrl('/dashboard/student');
          } else this.loginErr = response.error;
        });
  }
}
