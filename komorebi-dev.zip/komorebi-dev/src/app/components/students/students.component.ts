import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-students',
  templateUrl: './students.component.html',
  styleUrls: ['./students.component.css'],
})
export class StudentsComponent implements OnInit {
  userSession: User = new User();
  studentData: User = new User();
  studentDataErr: any = {};
  isAddStudent: boolean = false;
  msgSent: boolean = false;
  studentList: User[] = [];
  studentDocList: any[] = [];
  studentAction: string | null = '';
  studentActionId: number | undefined = undefined;
  studentMsg: any = [];
  msgToStudent: string = '';

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'students';

    this.commonService
      .fetchAllStudents(this.userSession.id)
      .subscribe((response) => {
        this.studentList = response.data;
      });

    if (
      this.route.snapshot.paramMap.has('action') &&
      this.route.snapshot.paramMap.has('id')
    ) {
      this.studentAction = this.route.snapshot.paramMap.get('action');
      this.studentActionId = Number(this.route.snapshot.paramMap.get('id'));

      if (this.studentAction == 'edit')
        this.commonService
          .fetchUserById(this.studentActionId)
          .subscribe((response) => {
            this.isAddStudent = true;
            this.studentData = response.data[0];
          });

      if (this.studentAction == 'delete')
        this.commonService
          .deleteUserById(this.studentActionId)
          .subscribe((response) => {
            if (response.success) {
              this.studentDataErr.delete = 1;
              this.clear();
            }
          });

      if (this.studentAction == 'chat')
        this.commonService
          .getStudentLastMsg(this.studentActionId, this.userSession.id)
          .subscribe((response) => {
            if (response.success) this.studentMsg = response.data;
            else this.studentDataErr.msg = response.error;
          });

      if (this.studentAction == 'list') this.fetchDocList(this.studentActionId);

      if (this.studentAction == 'view') {
        this.commonService
          .fetchUserById(this.studentActionId)
          .subscribe((response) => {
            this.studentData = response.data[0];
          });

        this.fetchDocList(this.studentActionId);
      }
    }
  }

  toggleAddStudent(): void {
    this.isAddStudent = !this.isAddStudent;

    if (this.studentAction != '') this.router.navigateByUrl('/students');
  }

  clear(): void {
    this.studentData = new User();
    this.studentAction = '';
    this.studentActionId = undefined;
  }

  closeMsg(wrapper: string) {
    if (wrapper == 'docErr') this.studentDataErr.docErr == null;
    else if (wrapper == 'docReq') this.studentDataErr.docReq = null;
    else if (wrapper == 'delete') this.studentDataErr.delete = null;
    else if (wrapper == 'msg') this.msgSent = false;
  }

  fetchDocList(id: number | undefined) {
    if (this.util.isNotNullOrEmptyOrUndefined(id)) {
      this.commonService
        .fetchDocumentListForOrg(id, this.userSession.id)
        .subscribe((response) => {
          if (response.success) {
            this.studentDocList = response.data;
          } else this.studentDataErr.docErr = response.error;
        });
    }
  }

  sendMessage(): void {
    let msg: any = {};

    msg.f = this.userSession.id;
    msg.t = this.studentActionId;
    msg.msg = this.msgToStudent;

    this.commonService.sendMessage(msg).subscribe((response) => {
      if (response.success) this.msgSent = true;
      else this.studentDataErr.msg = response.error;
    });
  }

  validateStudentData(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.studentData.name)) {
      validated = false;
      this.studentDataErr.name = 'Name is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.studentData.email)) {
      validated = false;
      this.studentDataErr.email = 'Email is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.studentData.password)) {
      validated = false;
      this.studentDataErr.password = 'Password is mandatory';
    }

    return validated;
  }

  addStudent(): void {
    if (this.validateStudentData()) {
      this.studentData.updatedBy = Number(this.userSession.id);
      this.studentData.updatedOn = new Date();

      if (this.util.isNullOrEmptyOrUndefined(this.studentActionId)) {
        this.studentData.username = this.studentData.email;
        this.studentData.category = 'student';
        this.studentData.orgId = Number(this.userSession.id);
        this.studentData.createdBy = Number(this.userSession.id);
        this.studentData.createdOn = new Date();

        this.commonService.signup(this.studentData).subscribe((response) => {
          if (response.success) {
            this.studentDataErr.add = 'Student added successfully';
            this.clear();
          } else this.studentDataErr.addErr = response.error;
        });
      } else
        this.commonService
          .updateUser(this.studentData)
          .subscribe((response) => {
            if (response.success) {
              this.studentDataErr.add = 'Student updated successfully';
              this.clear();
            } else this.studentDataErr.addErr = response.error;
          });
    }
  }

  requestDocument(studentId: number | undefined): void {
    if (this.util.isNotNullOrEmptyOrUndefined(studentId)) {
      this.commonService
        .requestDocument(this.userSession.id, studentId)
        .subscribe((response) => {
          if (response.success) this.studentDataErr.docReq = response.data;
          else this.studentDataErr.docErr = response.error;
        });
    }
  }
}
