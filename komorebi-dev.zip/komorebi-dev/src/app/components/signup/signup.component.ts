import { Router } from '@angular/router';
import { UtilService } from './../../services/util.service';
import { CommonService } from './../../services/common.service';
import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  activeSignup: string = 'organization';

  userData: User = new User();
  userDataErr: any = {};

  constructor(
    private commonService: CommonService,
    private router: Router,
    private util: UtilService
  ) {}

  ngOnInit(): void {
    this.commonService.activeComponent = 'signup';
  }

  toggleSignup(element: string) {
    this.userData = new User();
    this.activeSignup = element;
  }

  validateSignUp(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.userData.username)) {
      validated = false;
      this.userDataErr.username = 'Username is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.userData.password)) {
      validated = false;
      this.userDataErr.password = 'Password is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.userData.email)) {
      validated = false;
      this.userDataErr.email = 'Email is mandatory';
    }

    if (
      this.util.isNullOrEmptyOrUndefined(this.userData.orgId) &&
      this.activeSignup == 'student'
    ) {
      validated = false;
      this.userDataErr.orgId = 'Organization is mandatory';
    }

    return validated;
  }

  signup(): void {
    if (this.validateSignUp()) {
      this.userData.name = this.userData.username;
      this.userData.category = this.activeSignup;
      this.userData.createdOn = new Date();
      this.userData.updatedOn = new Date();
      this.userData.enabled = true;
      this.commonService.signup(this.userData).subscribe((response) => {
        if (response.success) this.router.navigateByUrl('/dashboard');
        else this.userDataErr.signupErr = response.error;
      });
    }
  }
}
