import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from 'src/app/models/user';
import { CommonService } from 'src/app/services/common.service';
import { UtilService } from 'src/app/services/util.service';

@Component({
  selector: 'app-internships',
  templateUrl: './internships.component.html',
  styleUrls: ['./internships.component.css'],
})
export class InternshipsComponent implements OnInit {
  userSession: User = new User();
  internshipsData: any = {};
  internshipsDataErr: any = {};
  isAddInternships: boolean = false;
  internshipsList: any[] = [];
  docList: any[] = [];
  internshipsAction: string | null = '';
  internshipsActionId: number | undefined = undefined;

  constructor(
    private commonService: CommonService,
    private util: UtilService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    this.userSession = commonService.getUserSession();

    if (util.isNullOrEmptyOrUndefined(this.userSession.id))
      console.log('Logging out');
  }

  ngOnInit(): void {
    this.commonService.activeComponent = 'internships';

    this.fetchAllInternships();

    if (
      this.route.snapshot.paramMap.has('action') ||
      this.route.snapshot.paramMap.has('id')
    ) {
      this.internshipsAction = this.route.snapshot.paramMap.get('action');
      this.internshipsActionId = Number(this.route.snapshot.paramMap.get('id'));

      if (this.internshipsAction == 'edit')
        this.commonService
          .fetchInternshipById(this.internshipsActionId)
          .subscribe((response) => {
            this.isAddInternships = true;
            this.internshipsData = response.data[0];
          });

      if (this.internshipsAction == 'delete')
        this.commonService
          .deleteInternshipById(this.internshipsActionId)
          .subscribe((response) => {
            if (response.success) {
              this.internshipsDataErr.delete = 1;
              this.router.navigateByUrl('/internships');
            }
          });

      if (this.internshipsAction == 'view')
        this.commonService
          .fetchInternshipById(this.internshipsActionId)
          .subscribe((response) => {
            if (response.success) this.internshipsData = response.data[0];
            else this.internshipsDataErr.view = response.error;
          });
    }
  }

  clear(): void {
    this.internshipsAction = '';
    this.internshipsActionId = undefined;
    this.internshipsData = {};
    this.internshipsDataErr = {};
    this.isAddInternships = false;
  }

  toggleAddInternship(): void {
    this.isAddInternships = !this.isAddInternships;

    if (this.internshipsAction != '') this.router.navigateByUrl('/internships');
  }

  fetchAllInternships(): void {
    if (this.userSession.category == 'organization')
      this.commonService
        .fetchInternshipsByOrgId(this.userSession.id)
        .subscribe((response) => {
          this.internshipsList = response.data;
        });
    else
      this.commonService.fetchAllInternships().subscribe((response) => {
        this.internshipsList = response.data;
      });
  }

  applyInternship(internshipId: number): void {
    let applicationData: any = {};

    applicationData.internshipId = internshipId;
    applicationData.applicantId = this.userSession.id;

    this.internshipsDataErr = {};

    this.commonService
      .applyInternship(applicationData)
      .subscribe((response) => {
        if (response.success)
          this.internshipsDataErr.view = 'Applied successfully';
        else this.internshipsDataErr.viewErr = response.error;
      });
  }

  validateInternshipData(): boolean {
    let validated = true;

    if (this.util.isNullOrEmptyOrUndefined(this.internshipsData.title)) {
      validated = false;
      this.internshipsDataErr.title = 'Title is mandatory';
    }

    if (this.util.isNullOrEmptyOrUndefined(this.internshipsData.description)) {
      validated = false;
      this.internshipsDataErr.description = 'Description is mandatory';
    }

    return validated;
  }

  addInternship(): void {
    if (this.validateInternshipData()) {
      this.internshipsData.orgId = this.userSession.id;
      this.internshipsData.updatedBy = Number(this.userSession.id);
      this.internshipsData.updatedOn = new Date();

      if (this.util.isNullOrEmptyOrUndefined(this.internshipsActionId)) {
        this.internshipsData.createdBy = Number(this.userSession.id);
        this.internshipsData.createdOn = new Date();

        this.commonService
          .createInternship(this.internshipsData)
          .subscribe((response) => {
            if (response.success) {
              this.internshipsDataErr.add = 'Internship added successfully';
              this.fetchAllInternships();
              this.clear();
            } else this.internshipsDataErr.addErr = response.error;
          });
      } else
        this.commonService
          .updateInternship(this.internshipsData)
          .subscribe((response) => {
            if (response.success) {
              this.internshipsDataErr.add = 'Internships updated successfully';
            } else this.internshipsDataErr.addErr = response.error;
            this.router.navigateByUrl('/internships');
          });
    }
  }
}
