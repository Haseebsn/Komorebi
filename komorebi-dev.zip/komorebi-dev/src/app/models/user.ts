export class User {
  id?: number;
  name: string;
  username: string;
  password: string;
  email: string;
  category: string;
  orgId: number;
  createdBy: number;
  createdOn: Date;
  updatedBy: number;
  updatedOn: Date;
  enabled: boolean;

  constructor() {
    this.name = '';
    this.username = '';
    this.password = '';
    this.email = '';
    this.category = '';
    this.orgId = 0;
    this.createdBy = 0;
    this.createdOn = new Date();
    this.updatedBy = 0;
    this.updatedOn = new Date();
    this.enabled = true;
  }
}
