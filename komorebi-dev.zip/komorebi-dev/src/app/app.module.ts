import { AuthInterceptor } from './services/authInterceptor';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/common/header/header.component';
import { FooterComponent } from './components/common/footer/footer.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { LeftbarComponent } from './components/common/leftbar/leftbar.component';
import { StudentDashboardComponent } from './components/student-dashboard/student-dashboard.component';
import { OrganizationsComponent } from './components/organizations/organizations.component';
import { StudentsComponent } from './components/students/students.component';
import { ContactsComponent } from './components/contacts/contacts.component';
import { UsersComponent } from './components/users/users.component';
import { PasswordComponent } from './components/password/password.component';
import { SignupComponent } from './components/signup/signup.component';
import { FormsModule } from '@angular/forms';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { ProfileComponent } from './components/profile/profile.component';
import { InternshipsComponent } from './components/internships/internships.component';
import { CompanyComponent } from './components/company/company.component';
import { NgxStarRatingModule } from 'ngx-star-rating';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    DashboardComponent,
    LeftbarComponent,
    StudentDashboardComponent,
    OrganizationsComponent,
    StudentsComponent,
    ContactsComponent,
    UsersComponent,
    PasswordComponent,
    SignupComponent,
    ResetPasswordComponent,
    ProfileComponent,
    InternshipsComponent,
    CompanyComponent,
  ],
  imports: [BrowserModule, AppRoutingModule, HttpClientModule, FormsModule, NgxStarRatingModule],
  providers: [
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {}
