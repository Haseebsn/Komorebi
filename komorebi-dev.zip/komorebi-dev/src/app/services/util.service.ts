import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UtilService {

  constructor() { }

  public isNullOrEmptyOrUndefined(obj: any ) {

      if ( obj == "" || obj == null || obj == undefined || JSON.stringify( obj ) === JSON.stringify( {} ) )
          return true;
      else
          return false;
  }

  public isNotNullOrEmptyOrUndefined(obj: any ) {
      if ( obj == "" || obj == null || obj == undefined )
          return false;
      else
          return true;
  }


  public isNullOrUndefined(obj: any ) {
      if ( obj == null || obj == undefined )
          return true;
      else
          return false;
  }


  public isNotNullOrUndefined(obj: any ) {
      if ( obj == null || obj == undefined )
          return false;
      else
          return true;
  }
}
