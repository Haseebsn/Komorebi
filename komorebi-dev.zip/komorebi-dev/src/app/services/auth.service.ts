import { User } from './../models/user';
import { Injectable } from '@angular/core';
import jwt_decode from 'jwt-decode';

@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor() {}

  setSession(authResult: any): User {
    // const expiresAt = moment().add(authResult.expiresIn, 'second');

    localStorage.setItem('access_token', authResult);

    let userData: { exp: number; iat: number; userData: {}; userId: number } =
      jwt_decode(authResult);
    localStorage.setItem('user_data', JSON.stringify(userData.userData));
    // localStorage.setItem('expires_at', JSON.stringify(expiresAt.valueOf()));

    return this.getSession();
  }

  getSession(): User {
    let user: User = new User();
    let session = localStorage.getItem('user_data');
    if (session !== null) user = JSON.parse(session);
    return user;
  }

  clearSession(): boolean {
    localStorage.clear();

    return localStorage.getItem('user_data') == null;
  }
}
