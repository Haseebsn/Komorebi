import { AuthService } from './auth.service';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  activeComponent: string = 'login';
  docCount: number = 0;

  constructor(private http: HttpClient, private authService: AuthService) {}

  authenticate(username: any, password: any): Observable<any> {
    return this.http.post<any>('/komorebi/login', {
      username: username,
      password: password,
    });
  }

  getUserSession(): User {
    return this.authService.getSession();
  }

  setUserSession(token: string): User {
    return this.authService.setSession(token);
  }

  clearSession(): boolean {
    return this.authService.clearSession();
  }

  signup(userData: User): Observable<any> {
    return this.http.post<any>('/komorebi/signup', userData);
  }

  changePassword(pwdData: any) {
    return this.http.post<any>('/komorebi/password/change', pwdData);
  }

  verifyUser(username: string) {
    return this.http.post<any>('/komorebi/users/verify', {
      username: username,
    });
  }

  resetPassword(username: string, password: string) {
    return this.http.post<any>('/komorebi/password/reset', {
      username: username,
      password: password,
    });
  }

  updateUser(userData: User): Observable<any> {
    return this.http.post<any>('/komorebi/users/update', userData);
  }

  getStudents(): Observable<any> {
    return this.http.get<any>('/komorebi/students/fetchCount');
  }

  fetchUserById(userId: number) {
    return this.http.get<any>('/komorebi/users/id?id=' + userId);
  }

  deleteUserById(userId: number) {
    return this.http.get<any>('/komorebi/users/delete?id=' + userId);
  }

  fetchAllStudents(id: number | undefined): Observable<any> {
    return this.http.get<any>('/komorebi/students/fetchAll?orgId=' + id);
  }

  getStudentLastMsg(
    from: number | undefined,
    to: number | undefined
  ): Observable<any> {
    return this.http.get<any>('/komorebi/message?f=' + from + '&t=' + to);
  }

  sendMessage(msg: any) {
    return this.http.post<any>('/komorebi/message/send', msg);
  }

  fetchAllChats(userId: number): Observable<any> {
    return this.http.get<any>('/komorebi/message/allChats?i=' + userId);
  }

  getOrganizations(): Observable<any> {
    return this.http.get<any>('/komorebi/organizations/fetchCount');
  }

  fetchAllOrganizations(): Observable<any> {
    return this.http.get<any>('/komorebi/organizations/fetchAll');
  }

  getJobs(): Observable<any> {
    return this.http.get<any>('/komorebi/jobs/fetchCount');
  }

  fetchJobsByOrgId(userId: number | undefined): Observable<any> {
    return this.http.get<any>('/komorebi/jobs/fetchAll?orgId=' + userId);
  }

  fetchAllJobs(): Observable<any> {
    return this.http.get<any>('/komorebi/jobs/fetchAll');
  }

  fetchJobById(jobId: number) {
    return this.http.get<any>('/komorebi/jobs/id?id=' + jobId);
  }

  createJob(jobsData: any) {
    return this.http.post<any>('/komorebi/jobs/addJobs', jobsData);
  }

  updateJob(jobsData: any) {
    return this.http.post<any>('/komorebi/jobs/update', jobsData);
  }

  deleteJobById(jobId: number) {
    return this.http.get<any>('/komorebi/jobs/delete?id=' + jobId);
  }

  applyJob(applicationData: any) {
    return this.http.post<any>('/komorebi/jobs/apply', applicationData);
  }

  fetchInternshipsByOrgId(userId: number | undefined): Observable<any> {
    return this.http.get<any>('/komorebi/internships/fetchAll?orgId=' + userId);
  }

  fetchAllInternships(): Observable<any> {
    return this.http.get<any>('/komorebi/internships/fetchAll');
  }

  fetchInternshipById(internshipId: number) {
    return this.http.get<any>('/komorebi/internships/id?id=' + internshipId);
  }

  createInternship(internshipsData: any) {
    return this.http.post<any>('/komorebi/internships/add', internshipsData);
  }

  updateInternship(internshipsData: any) {
    return this.http.post<any>('/komorebi/internships/update', internshipsData);
  }

  deleteInternshipById(internshipId: number) {
    return this.http.get<any>(
      '/komorebi/internships/delete?id=' + internshipId
    );
  }

  applyInternship(applicationData: any) {
    return this.http.post<any>('/komorebi/internships/apply', applicationData);
  }

  requestDocument(
    requestFrom: number | undefined,
    studentId: number | undefined
  ) {
    return this.http.get<any>(
      '/komorebi/documents/request?f=' + requestFrom + '&t=' + studentId
    );
  }

  fetchDocumentList(id: number | undefined) {
    return this.http.get<any>('/komorebi/documents/id?id=' + id);
  }

  fetchDocumentListForOrg(id: number | undefined, orgId: number | undefined) {
    return this.http.get<any>(
      '/komorebi/documents/org?id=' + id + '&orgId=' + orgId
    );
  }

  fetchDocumentListOfOrg(orgId: number) {
    return this.http.get<any>(
      '/komorebi/documents/organization?orgId=' + orgId
    );
  }

  uploadDocument(fileData: any) {
    return this.http.post<any>('/komorebi/documents/upload', fileData);
  }

  rateCompany(ratingData: any) {
    return this.http.post<any>('/komorebi/organizations/rate', ratingData);
  }

  fetchCompanyRating(companyId: any) {
    return this.http.get<any>(
      '/komorebi/organizations/fetch/rate?i=' + companyId
    );
  }
}
