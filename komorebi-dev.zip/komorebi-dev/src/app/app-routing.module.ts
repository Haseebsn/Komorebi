import { CompanyComponent } from './components/company/company.component';
import { InternshipsComponent } from './components/internships/internships.component';
import { ProfileComponent } from './components/profile/profile.component';
import { ResetPasswordComponent } from './components/reset-password/reset-password.component';
import { SignupComponent } from './components/signup/signup.component';
import { PasswordComponent } from './components/password/password.component';
import { UsersComponent } from './components/users/users.component';
import { ContactsComponent } from './components/contacts/contacts.component';
import { StudentDashboardComponent } from './components/student-dashboard/student-dashboard.component';
import { StudentsComponent } from './components/students/students.component';
import { OrganizationsComponent } from './components/organizations/organizations.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { LoginComponent } from './components/login/login.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'organization', component: OrganizationsComponent },
  { path: 'organization/:action/:id', component: OrganizationsComponent },
  { path: 'students', component: StudentsComponent },
  { path: 'students/:action/:id', component: StudentsComponent },
  { path: 'dashboard/student', component: StudentDashboardComponent },
  { path: 'dashboard/student/:action', component: StudentDashboardComponent },
  {
    path: 'dashboard/student/:action/:id',
    component: StudentDashboardComponent,
  },
  { path: 'contacts', component: ContactsComponent },
  { path: 'inbox', component: UsersComponent },
  { path: 'password', component: PasswordComponent },
  { path: 'reset', component: ResetPasswordComponent },
  { path: 'profile', component: ProfileComponent },
  { path: 'internships', component: InternshipsComponent },
  { path: 'internships/:action/:id', component: InternshipsComponent },
  { path: 'company/:id', component: CompanyComponent },
  { path: '**', component: LoginComponent },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
})
export class AppRoutingModule {}
