 $(document).ready(function () {

	 

 	$(".ts-sidebar-menu li a").each(function () {

 		if ($(this).next().length > 0) {

 			$(this).addClass("parent");

 		};

 	})

 	var menux = $('.ts-sidebar-menu li a.parent');

 	$('<div class="more"><i class="fa fa-angle-down"></i></div>').insertBefore(menux);

 	$('.more').click(function () {

 		$(this).parent('li').toggleClass('open');

 	});

	$('.parent').click(function (e) {

		e.preventDefault();

 		$(this).parent('li').toggleClass('open');

 	});

 	$('.menu-btn').click(function () {

 		$('nav.ts-sidebar').toggleClass('menu-open');

 	});

	 

	 

	 //$('#zctb').DataTable();

	 $('#zctb').dataTable( {
  		"pageLength": 100,
		dom: "<'row'<'col-sm-3'l><'col-sm-3'f><'col-sm-6'p>>" +
"<'row'<'col-sm-12'tr>>" 
	} );

	 

	 $("#input-43").fileinput({

		showPreview: false,

		allowedFileExtensions: ["zip", "rar", "gz", "tgz"],

		elErrorContainer: "#errorBlock43"

			// you can configure `msgErrorClass` and `msgInvalidFileExtension` as well

	});



 });
var btn = $('#b2tbutton');

$(window).scroll(function() {
  if ($(window).scrollTop() > 100) {
    btn.addClass('show');
  } else {
    btn.removeClass('show');
  }
});

btn.on('click', function(e) {
  e.preventDefault();
  $('html, body').animate({scrollTop:0}, '100');
});


