var express = require('express');
var connection = require('./connection');
var router = express.Router();

router.get('/', function (req, res, next) {

    const from = req.query.f;
    const to = req.query.t;

    connection.query(
        'SELECT * FROM `message_master` WHERE msgFrom=? AND msgTo=?', [from, to],
        function (err, results, fields) {
            console.log(results);

            if (err) {
                return res
                    .status(400)
                    .json({
                        success: false,
                        error: "Something went wrong: " + err,
                    });
            }

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.post('/send', function (req, res, next) {
    var f = req.body.f;
    var t = req.body.t;
    var msg = req.body.msg;

    var sql = `INSERT INTO message_master (msgFrom, msgTo, msg, createdBy, updatedBy) VALUES (?, ?, ?, ?, ?)`;
    var values = [f, t, msg, f, f];

    connection.query(sql, values, function (err, result) {
        if (err) {
            return res
                .status(400)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        };
        console.log("Number of records inserted: " + result.affectedRows);

        return res
            .status(200)
            .json({
                success: true,
                data: result
            });

    });
});

router.get('/allChats', function (req, res, next) {
    var userId = req.query.i;

    connection.query("SELECT msg.*, fuser.name AS sender, tuser.name AS receiver FROM message_master msg LEFT JOIN users fuser ON msg.msgFrom = fuser.id LEFT JOIN users tuser ON msg.msgTo = tuser.id WHERE msgFrom = ? OR msgTo = ? ORDER BY msg.id ASC", [userId, userId], function (err, results) {
        if (err) {
            return res
                .status(400)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        };
        console.log("Number of records fetched: " + results.length);

        return res
            .status(200)
            .json({
                success: true,
                data: results
            });
    });
});

module.exports = router;