var express = require('express');
var connection = require('./connection');
var router = express.Router();

router.post('/update', function (req, res, next) {

    const user = req.body;

    var sql = 'UPDATE `internships` SET  title=?, description=?, updatedBy=? WHERE id=?';
    var values = [user.title, user.description, user.updatedBy, user.id];

    connection.query(sql, values, function (err, result) {
        if (err) {
            return res
                .status(200)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        }
        console.log("Number of records inserted: " + result.affectedRows);

        res
            .status(200)
            .json({
                success: true,
                data: result,
            });
    });

});

router.get('/id', function (req, res, next) {

    const id = req.query.id;
    // simple query
    connection.query(
        'SELECT `internships`.*, `users`.`name` AS `postedBy` FROM `internships` LEFT JOIN `users` ON `internships`.`orgId` = `users`.`id` WHERE `internships`.`id`=' + id,
        function (err, results, fields) {
            console.log(results);

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.get('/delete', function (req, res, next) {

    const id = req.query.id;

    // simple query
    connection.query(
        'UPDATE `internships` SET enabled="0" WHERE id=' + id,
        function (err, results, fields) {
            console.log(results);

            if (results.affectedRows == 1) {
                res
                    .status(200)
                    .json({
                        success: true,
                        data: "Deleted Successfully",
                    });
            }
        });
});

router.post('/add', function (req, res, next) {

    var user = req.body;
    var sql = `INSERT INTO internships (title, description, orgId, createdBy, updatedBy) VALUES (?, ?, ?, ?, ?)`;
    var values = [user.jobId, user.title, user.description, user.orgId, user.createdBy, user.updatedBy];

    connection.query(sql, values, function (err, result) {
        if (err) {
            return res
                .status(200)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        };
        console.log("Number of records inserted: " + result.affectedRows);
        return res
            .status(200)
            .json({
                success: true,
                data: result
            });

    });

});

router.get('/fetchCount', function (req, res, next) {
    connection.query(
        'SELECT COUNT(*) AS internshipsCount FROM `internships`',
        function (err, results, fields) {
            console.log(results[0]);

            res
                .status(200)
                .json({
                    success: true,
                    data: results[0],
                });
        });

});

router.get('/fetchAll', function (req, res, next) {
    var orgId = null;
    if (!req.query)
        orgId = req.query.orgId;

    if (orgId != null)
        connection.query(
            'SELECT * FROM `internships` WHERE enabled="1" AND orgId=' + orgId,
            function (err, results, fields) {
                console.log(results);

                return res
                    .status(200)
                    .json({
                        success: true,
                        data: results,
                    });
            });
    else
        connection.query(
            'SELECT * FROM `internships` WHERE enabled="1"',
            function (err, results, fields) {
                console.log(results);

                return res
                    .status(200)
                    .json({
                        success: true,
                        data: results,
                    });
            });
});

router.post('/apply', function (req, res, next) {
    var internship = req.body;
    var sql = `INSERT INTO internship_application_master (internshipId, applicantId, createdBy, updatedBy) VALUES (?, ?, ?, ?)`;
    var values = [internship.internshipId, internship.applicantId, internship.applicantId, internship.applicantId];

    connection.query(sql, values, function (err, result) {
        if (err) {
            return res
                .status(500)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        };
        console.log("Number of records inserted: " + result.affectedRows);
        return res
            .status(200)
            .json({
                success: true,
                data: result.affectedRows
            });

    });
});

module.exports = router;