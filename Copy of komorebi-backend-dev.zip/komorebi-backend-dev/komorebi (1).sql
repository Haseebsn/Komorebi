-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 29, 2023 at 06:17 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `komorebi`
--

-- --------------------------------------------------------

--
-- Table structure for table `document_master`
--

CREATE TABLE `document_master` (
  `id` int(11) NOT NULL,
  `fileType` enum('1','2','3') NOT NULL,
  `filePath` varchar(255) NOT NULL,
  `requestId` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `document_master`
--

INSERT INTO `document_master` (`id`, `fileType`, `filePath`, `requestId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, '1', './uploads/Candidate Information Sheet-v6.pdf', 1, 1, '2023-03-26 19:35:21', 1, '2023-03-26 19:35:21', '1'),
(2, '1', './uploads/sitemap.xml', 2, 1, '2023-03-26 19:36:26', 1, '2023-03-26 19:36:26', '1'),
(3, '1', './uploads/Candidate Information Sheet-v6.pdf', 2, 1, '2023-03-26 19:36:26', 1, '2023-03-26 19:36:26', '1'),
(4, '1', './uploads/sitemap.xml', 3, 1, '2023-03-26 19:38:00', 1, '2023-03-26 19:38:00', '1'),
(5, '1', './uploads/Candidate Information Sheet-v6.pdf', 3, 1, '2023-03-26 19:38:00', 1, '2023-03-26 19:38:00', '1'),
(6, '1', './uploads/My Family Should Know.pdf', 4, 1, '2023-03-26 19:50:43', 1, '2023-03-26 19:50:43', '1'),
(7, '1', './uploads/My Family Should Know.pdf', 4, 1, '2023-03-26 19:51:38', 1, '2023-03-26 19:51:38', '1'),
(8, '1', './uploads/My Family Should Know.pdf', 4, 1, '2023-03-26 19:54:14', 1, '2023-03-26 19:54:14', '1'),
(9, '1', './uploads/My Family Should Know.pdf', 4, 1, '2023-03-26 19:55:25', 1, '2023-03-26 19:55:25', '1'),
(10, '1', './uploads/My Family Should Know.pdf', 4, 1, '2023-03-26 19:59:34', 1, '2023-03-26 19:59:34', '1'),
(11, '1', './uploads/My Family Should Know.pdf', 5, 1, '2023-03-26 20:01:32', 1, '2023-03-26 20:01:32', '1'),
(12, '1', './uploads/My Family Should Know.pdf', 0, 4, '2023-03-26 20:01:32', 4, '2023-03-26 20:01:32', '1');

-- --------------------------------------------------------

--
-- Table structure for table `document_request_master`
--

CREATE TABLE `document_request_master` (
  `id` int(11) NOT NULL,
  `requestFrom` int(11) NOT NULL,
  `requestTo` int(11) NOT NULL,
  `isUploaded` enum('0','1') NOT NULL DEFAULT '0',
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `document_request_master`
--

INSERT INTO `document_request_master` (`id`, `requestFrom`, `requestTo`, `isUploaded`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 4, 1, '1', 4, '2023-03-26 07:33:35', 4, '2023-03-26 19:45:08', '1'),
(2, 4, 1, '1', 4, '2023-03-26 07:34:59', 4, '2023-03-26 19:45:13', '1'),
(3, 4, 1, '1', 4, '2023-03-26 08:29:51', 4, '2023-03-26 19:45:29', '1'),
(4, 4, 1, '1', 4, '2023-03-26 08:30:12', 4, '2023-03-26 19:59:34', '1'),
(5, 4, 1, '1', 4, '2023-03-26 08:34:54', 4, '2023-03-26 20:01:32', '1');

-- --------------------------------------------------------

--
-- Table structure for table `internships`
--

CREATE TABLE `internships` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `orgId` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `internships`
--

INSERT INTO `internships` (`id`, `title`, `description`, `orgId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 'manager\'s internship', 'very nice job', 12, 1, '2023-03-25 00:59:14', 4, '2023-03-27 08:13:16', '1'),
(2, 'ASD', 'Good', 4, 1, '2023-03-25 19:14:24', 1, '2023-03-25 22:08:49', '0'),
(3, 'ASD', 'Good', 4, 1, '2023-03-25 19:19:22', 1, '2023-03-25 22:17:00', '0'),
(4, 'Third Job updated', 'details', 4, 4, '2023-03-25 21:16:31', 4, '2023-03-25 22:17:48', '0'),
(5, 'Fourth Job', 'Details', 4, 4, '2023-03-25 21:24:33', 4, '2023-03-25 22:24:03', '0'),
(6, '5th internship', 'abc', 4, 4, '2023-03-25 21:25:45', 4, '2023-03-27 08:13:52', '1'),
(7, '6th', 'dey', 4, 4, '2023-03-25 21:26:15', 4, '2023-03-25 21:26:15', '1'),
(8, '7th', 'sdf', 4, 4, '2023-03-25 21:27:44', 4, '2023-03-27 08:16:36', '0');

-- --------------------------------------------------------

--
-- Table structure for table `internship_application_master`
--

CREATE TABLE `internship_application_master` (
  `id` int(11) NOT NULL,
  `internshipId` int(11) NOT NULL,
  `applicantId` int(11) NOT NULL,
  `createdBy` varchar(255) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `internship_application_master`
--

INSERT INTO `internship_application_master` (`id`, `internshipId`, `applicantId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 1, 13, '13', '2023-03-27 13:34:09', 13, '2023-03-27 13:34:09', '1'),
(2, 1, 13, '13', '2023-03-27 13:35:02', 13, '2023-03-27 13:35:02', '1'),
(3, 1, 13, '13', '2023-03-27 13:58:28', 13, '2023-03-27 13:58:28', '1');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` int(11) NOT NULL,
  `jobId` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` longtext NOT NULL,
  `orgId` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`id`, `jobId`, `title`, `description`, `orgId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, '', 'manager', 'very nice job', 12, 1, '2023-03-25 00:59:14', 1, '2023-03-25 00:59:14', '1'),
(2, '', 'ASD', 'Good', 4, 1, '2023-03-25 19:14:24', 1, '2023-03-25 22:08:49', '0'),
(3, '', 'ASD', 'Good', 4, 1, '2023-03-25 19:19:22', 1, '2023-03-25 22:17:00', '0'),
(4, '', 'Third Job updated', 'details', 4, 4, '2023-03-25 21:16:31', 4, '2023-03-25 22:17:48', '0'),
(5, '4', 'Fourth Job', 'Details', 4, 4, '2023-03-25 21:24:33', 4, '2023-03-25 22:24:03', '0'),
(6, '5', '5th job', 'abc', 4, 4, '2023-03-25 21:25:45', 4, '2023-03-25 21:25:45', '1'),
(7, '6', '6th', 'dey', 4, 4, '2023-03-25 21:26:15', 4, '2023-03-25 21:26:15', '1'),
(8, '7', '7th', 'sdf', 4, 4, '2023-03-25 21:27:44', 4, '2023-03-25 21:27:44', '1');

-- --------------------------------------------------------

--
-- Table structure for table `job_application_master`
--

CREATE TABLE `job_application_master` (
  `id` int(11) NOT NULL,
  `jobId` int(11) NOT NULL,
  `applicantId` int(11) NOT NULL,
  `createdBy` varchar(255) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `job_application_master`
--

INSERT INTO `job_application_master` (`id`, `jobId`, `applicantId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 1, 13, '13', '2023-03-27 13:34:09', 13, '2023-03-27 13:34:09', '1'),
(2, 1, 13, '13', '2023-03-27 13:35:02', 13, '2023-03-27 13:35:02', '1');

-- --------------------------------------------------------

--
-- Table structure for table `message_master`
--

CREATE TABLE `message_master` (
  `id` int(11) NOT NULL,
  `msgFrom` int(11) NOT NULL,
  `msgTo` int(11) NOT NULL,
  `msg` longtext NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `message_master`
--

INSERT INTO `message_master` (`id`, `msgFrom`, `msgTo`, `msg`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 4, 13, 'Hi student', 4, '2023-03-26 21:18:28', 4, '2023-03-26 21:18:28', '1'),
(2, 4, 13, 'Welcome to venture systems', 4, '2023-03-26 21:20:01', 4, '2023-03-26 21:20:01', '1'),
(3, 4, 13, 'Welcome to venture systems', 4, '2023-03-26 21:20:01', 4, '2023-03-26 21:20:01', '1'),
(4, 13, 4, 'Hello. I wanted to apply for your job post', 13, '2023-03-27 11:09:00', 13, '2023-03-27 11:09:00', '1'),
(5, 13, 4, 'I\'m a full stack developer', 13, '2023-03-27 11:22:59', 13, '2023-03-27 11:22:59', '1'),
(6, 13, 4, 'Can I join?', 13, '2023-03-27 11:28:19', 13, '2023-03-27 11:28:19', '1'),
(7, 13, 4, 'Please accept this request ', 13, '2023-03-27 11:29:20', 13, '2023-03-27 11:29:20', '1');

-- --------------------------------------------------------

--
-- Table structure for table `rating_master`
--

CREATE TABLE `rating_master` (
  `id` int(11) NOT NULL,
  `rating` int(11) NOT NULL,
  `review` varchar(255) NOT NULL,
  `orgId` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rating_master`
--

INSERT INTO `rating_master` (`id`, `rating`, `review`, `orgId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 3, 'Very nice company', 4, 13, '2023-03-27 16:04:41', 13, '2023-03-27 16:04:41', '1'),
(2, 4, 'Nice', 4, 13, '2023-03-27 16:05:16', 13, '2023-03-27 16:05:16', '1'),
(3, 5, 'Wow', 4, 13, '2023-03-27 16:06:09', 13, '2023-03-27 16:06:09', '1');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `category` enum('admin','organization','student') NOT NULL,
  `orgId` int(11) NOT NULL,
  `createdBy` int(11) NOT NULL,
  `createdOn` timestamp NOT NULL DEFAULT current_timestamp(),
  `updatedBy` int(11) NOT NULL,
  `updatedOn` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `enabled` enum('0','1') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `password`, `email`, `category`, `orgId`, `createdBy`, `createdOn`, `updatedBy`, `updatedOn`, `enabled`) VALUES
(1, 'Student 4', 'chaudhari', '123', 'studentvishal@gmail.com', 'student', 12, 0, '2023-03-24 04:34:09', 4, '2023-03-26 08:44:42', '1'),
(2, 'Student 2', 'abc123', 'abc@123', 'studentvishal@gmail.com', 'admin', 3, 7, '2023-03-25 13:36:12', 4, '2023-03-25 21:07:10', '1'),
(4, 'MET BKC IoT-P', 'met', '123456', 'studentvishal@gmail.com', 'organization', 0, 0, '2023-03-25 07:56:55', 4, '2023-03-27 05:43:19', '1'),
(9, 'Student 3', 'sundipuniversity', '123', 'studentvishal@gmail.com', 'organization', 0, 0, '2023-03-25 08:14:11', 4, '2023-03-25 21:07:20', '1'),
(13, 'Student 5', 'vaibhav', '123', 'studentvishal@gmail.com', 'student', 12, 0, '2023-03-25 09:38:30', 4, '2023-03-25 21:07:28', '1'),
(14, 'Student 6', 'student1@gmail.com', '123456', 'studentvishal@gmail.com', 'student', 4, 4, '2023-03-25 18:27:21', 4, '2023-03-25 21:07:32', '0'),
(15, 'ABC', 'student2@gmail.com', '123456', 'abc@gmail.com', 'student', 4, 4, '2023-03-25 18:28:42', 4, '2023-03-25 21:07:38', '1'),
(16, 'Student 3', 'student12@gmail.com', '123456', 'student3@gmail.com', 'student', 4, 4, '2023-03-25 20:03:46', 4, '2023-03-25 21:07:42', '1'),
(17, 'KKW', 'kkw', '123', 'kkw', 'organization', 2, 2, '2023-03-25 22:56:10', 2, '2023-03-25 22:56:10', '1'),
(18, 'KKWPoly', 'kkwpoly', '123', 'kkwpoly', 'organization', 2, 2, '2023-03-25 22:56:32', 2, '2023-03-25 22:56:32', '1'),
(19, 'ndmvp', 'ndmvp', '123', 'ndmvp', 'organization', 2, 2, '2023-03-25 22:57:55', 2, '2023-03-25 22:57:55', '1'),
(20, 'test org', 'torg', '123', 'torg1', 'organization', 2, 2, '2023-03-25 23:00:03', 2, '2023-03-25 23:04:53', '0'),
(21, 'org', 'org', '123', 'org', 'organization', 2, 2, '2023-03-25 23:00:58', 2, '2023-03-25 23:02:45', '0');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `document_master`
--
ALTER TABLE `document_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `document_request_master`
--
ALTER TABLE `document_request_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internships`
--
ALTER TABLE `internships`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `internship_application_master`
--
ALTER TABLE `internship_application_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `job_application_master`
--
ALTER TABLE `job_application_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `message_master`
--
ALTER TABLE `message_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rating_master`
--
ALTER TABLE `rating_master`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `document_master`
--
ALTER TABLE `document_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `document_request_master`
--
ALTER TABLE `document_request_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `internships`
--
ALTER TABLE `internships`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `internship_application_master`
--
ALTER TABLE `internship_application_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `job_application_master`
--
ALTER TABLE `job_application_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `message_master`
--
ALTER TABLE `message_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `rating_master`
--
ALTER TABLE `rating_master`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
