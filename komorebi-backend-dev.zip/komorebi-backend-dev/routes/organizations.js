var express = require('express');
var connection = require('./connection');
var router = express.Router();
var multer = require('multer');
const upload = multer({ dest: "/" });

/* GET users listing. */
router.get('/id', function (req, res, next) {

    const orgId = req.query.orgId;
    // simple query
    connection.query(
        'SELECT * FROM `users` WHERE category="organization" AND orgId=' + + orgId,
        function (err, results, fields) {
            console.log(results);

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.get('/fetchAll', function (req, res, next) {

    const user = req.body;

    // simple query
    connection.query(
        'SELECT * FROM `users` WHERE enabled="1" AND category="organization"',
        function (err, results, fields) {
            console.log(results);


            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.get('/fetchCount', function (req, res, next) {

    const user = req.body;

    // simple query
    connection.query(
        'SELECT COUNT(*) AS orgCount FROM `users` WHERE category="organization"',
        function (err, results, fields) {
            console.log(results[0]);

            res
                .status(200)
                .json({
                    success: true,
                    data: results[0],
                });
        });
});

router.post('/rate', function (req, res, next) {

    const ratingData = req.body;

    connection.query(
        'INSERT INTO `rating_master` (rating, review, orgId, createdBy, updatedBy) VALUE(?, ?, ? , ?, ?)', [ratingData.rating, ratingData.review, ratingData.ratedTo, ratingData.ratedBy, ratingData.ratedBy],
        function (err, results, fields) {
            if (err)
                return res.status(500).json({ success: false, error: err.message });

            res
                .status(200)
                .json({
                    success: true,
                    data: results.affectedRows,
                });
        });
});

router.get('/fetch/rate', function (req, res, next) {

    const company = req.query.i;

    connection.query(
        'SELECT * FROM `rating_master` WHERE `orgId`=' + company,
        function (err, results, fields) {
            if (err)
                return res.status(500).json({ success: false, error: err.message });

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

module.exports = router;