const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const jwt = require("jsonwebtoken");
const nodemailer = require('nodemailer');

var router = express.Router();

var connection = require('./connection')

router.post('/', function (req, res, next) {

    const user = req.body;

    // simple query
    connection.query(
        'SELECT * FROM `users` WHERE username=?', [user.username],
        function (err, results, fields) {
            console.log(results[0]);
            if (results.length == 0) {
                return res
                    .status(200)
                    .json({
                        success: false,
                        error: "User does not exists",
                    });
            }

            if (results[0].password != user.password) {
                return res.status(200).json({ success: false, error: "Incorrect password", });
            }

            results.forEach(element => {

                const userToken = {};
                userToken.username = element.username
                userToken.id = element.id;
                userToken.category = element.category;
                userToken.email = element.email;
                userToken.name = element.name;

                let token;
                try {
                    //Creating jwt token
                    token = jwt.sign(
                        { userId: element.id, userData: userToken },
                        "venture",
                        { expiresIn: "1h" }
                    );
                } catch (err) {
                    console.log(err);
                    const error = new Error("Error! Something went wrong.");
                    return next(error);
                }

                sql = 'SELECT `users`.`twoFactAuth`, `email` FROM `users` WHERE `users`.`id`=?';
                values = [userToken.id];

                connection.query(sql, values, function (err, factResult) {
                    if (err) {
                        return res
                            .status(200)
                            .json({
                                success: false,
                                error: "Something went wrong: " + err,
                            });
                    }
                    console.log("Fetched records users for twoFactAuth: " + factResult.length);

                    if (factResult[0].twoFactAuth) {
                        let code = userCodeGenerator();

                        const transporter = nodemailer.createTransport({
                            port: 465,               // true for 465, false for other ports
                            host: "smtp.gmail.com",
                            auth: {
                                user: 'shahrukhzaman256@gmail.com',
                                pass: 'znszedtwblqolrao',
                            },
                            secure: true,
                        });

                        const mailData = {
                            from: 'vaibhav.mandlik2@gmail.com',  // sender address
                            to: factResult[0].email,   // list of receivers
                            subject: 'OTP for two-fact authentication',
                            html: '<b>OTP for Komorebi: </b> ' + code
                        };

                        transporter.sendMail(mailData, function (err, info) {
                            if (err) {
                                console.log(err)
                                res
                                    .status(400)
                                    .json({
                                        success: false,
                                        data: {
                                            error: err
                                        },
                                    });
                            }
                            else {
                                console.log(info);

                                connection.query("INSERT INTO `authentication_master` (otp, type, validUpto, createdBy) VALUES (?, ?, ?, ?)", [code, '0', new Date(new Date().getTime() + 5 * 60000), element.id], function (err, factResult) {
                                    if (err) {
                                        return res
                                            .status(200)
                                            .json({
                                                success: false,
                                                error: "Something went wrong: " + err,
                                            });
                                    }
                                    console.log("Inserted records in auth master: " + factResult.length);

                                    return res
                                        .status(200)
                                        .json({
                                            success: true,
                                            data: {
                                                userId: element.id,
                                                token: token,
                                                emailSent: true
                                            },
                                        });
                                });
                            }
                        });
                    }
                    else {
                        res
                            .status(200)
                            .json({
                                success: true,
                                data: {
                                    userId: element.id,
                                    token: token,
                                },
                            });
                    }
                });
            });
        }
    );

});

function userCodeGenerator() {
    var chars = '1234567890',
        serialLength = 4,
        randomSerial = "",
        i,
        randomNumber;

    for (i = 0; i < serialLength; i = i + 1) {
        randomNumber = Math.floor(Math.random() * chars.length);
        randomSerial += chars.substring(randomNumber, randomNumber + 1);
    }

    return randomSerial;
}

module.exports = router;