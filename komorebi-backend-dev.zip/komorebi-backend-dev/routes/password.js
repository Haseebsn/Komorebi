var express = require('express');
var connection = require('./connection');
var router = express.Router();

router.post('/change', function (req, res, next) {

    const uid = req.body.uid;
    const old = req.body.old;
    const newP = req.body.new;

    connection.query("SELECT password FROM users WHERE id=?", [uid], function (err, result) {
        if (err) {
            return res
                .status(400)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        }

        if (result[0].password == old) {
            var sql = 'UPDATE `users` SET  password=? WHERE id=?';
            var values = [newP, uid];

            connection.query(sql, values, function (err, result) {
                if (err) {
                    return res
                        .status(200)
                        .json({
                            success: false,
                            error: "Something went wrong: " + err,
                        });
                }
                console.log("Number of records inserted: " + result.affectedRows);

                res
                    .status(200)
                    .json({
                        success: true,
                        data: result,
                    });
            });
        } else
            return res
                .status(400)
                .json({
                    success: false,
                    error: "Old password does not match",
                });
    });


});

router.post('/reset', function (req, res, next) {

    const user = req.body.username;
    const password = req.body.password;

    var sql = 'UPDATE `users` SET  `password`="' + password + '" WHERE username="' + user + '"';

    connection.query(sql, function (err, result) {
        if (err) {
            return res
                .status(200)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        }
        console.log("Number of records inserted: " + result.affectedRows);

        if (result.affectedRows > 0)
            res
                .status(200)
                .json({
                    success: true,
                    data: "Password changed successfully",
                });
        else
            return res
                .status(200)
                .json({
                    success: false,
                    error: "Something went wrong: ",
                });
    });
});

module.exports = router;