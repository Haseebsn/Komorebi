var express = require('express');
var connection = require('./connection');
var router = express.Router();
var base64toFile = require('node-base64-to-file');

router.get('/id', function (req, res, next) {

    const id = req.query.id;
    // simple query
    connection.query(
        'SELECT `drm`.*, `users`.`name` FROM `document_request_master` AS `drm` LEFT JOIN `users` ON `drm`.`requestFrom` = `users`.`id` WHERE `drm`.`isUploaded`="0" AND requestTo=' + id,
        function (err, results, fields) {
            if (err) {
                console.log(err);
                return res
                    .status(200)
                    .json({
                        success: false,
                        error: "Something went wrong: " + err,
                    });
            }

            console.log(results);

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.get('/organization', function (req, res, next) {

    const orgId = req.query.orgId;
    // simple query
    try {
        connection.query(
            'SELECT * FROM `document_master` WHERE `createdBy`=?', [orgId],
            function (err, results, fields) {
                if (err) {
                    console.log(err);
                    return res
                        .status(500)
                        .json({
                            success: false,
                            error: "Something went wrong: " + err,
                        });
                }

                console.log(results);

                res
                    .status(200)
                    .json({
                        success: true,
                        data: results,
                    });
            });
    } catch (error) {
        console.log(error);

        return res
            .status(500)
            .json({
                success: false,
                error: "Something went wrong: " + err,
            });
    }
});

router.get('/org', function (req, res, next) {

    const id = req.query.id;
    const orgId = req.query.orgId;
    // simple query
    try {
        connection.query(
            'SELECT `drm`.*, `dm`.filePath FROM `document_request_master` AS `drm` LEFT JOIN `document_master` AS `dm` ON `drm`.`id`=`dm`.`requestId` WHERE `drm`.`isUploaded`="1" AND `drm`.`requestFrom`=? AND `drm`.`requestTo`=?', [orgId, id],
            function (err, results, fields) {
                if (err) {
                    console.log(err);
                    return res
                        .status(500)
                        .json({
                            success: false,
                            error: "Something went wrong: " + err,
                        });
                }

                console.log(results);

                res
                    .status(200)
                    .json({
                        success: true,
                        data: results,
                    });
            });
    } catch (error) {
        console.log(error);

        return res
            .status(500)
            .json({
                success: false,
                error: "Something went wrong: " + err,
            });
    }
});

router.get('/request', function (req, res, next) {

    var from = req.query.f;
    var to = req.query.t;

    connection.query(
        'INSERT INTO `document_request_master` (requestFrom, requestTo, createdBy, updatedBy) VALUES (?, ?, ?, ?)', [from, to, from, from],
        function (err, results, fields) {
            if (err) {
                return res
                    .status(200)
                    .json({
                        success: false,
                        error: "Something went wrong: " + err,
                    });
            };
            console.log("Number of records inserted: " + results.affectedRows);

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.post('/upload', async function (req, res, next) {

    var fileData = req.body;

    try {
        const filePath = await base64toFile(fileData.file, { filePath: './uploads', fileName: fileData.fileName });
        console.log("File moved to: ./uploads/" + filePath);

        if (filePath) {
            connection.query(
                'INSERT INTO `document_master` (filePath, requestId, createdBy, updatedBy) VALUES (?, ?, ?, ?)', ['./uploads/' + filePath, fileData.requestId, fileData.createdBy, fileData.updatedBy],
                function (err, results, fields) {
                    if (err) {
                        console.log(err.message);

                        return res
                            .status(200)
                            .json({
                                success: false,
                                error: "Something went wrong: " + err.message,
                            });
                    };

                    console.log("Number of records inserted: " + results.affectedRows);

                    connection.query('UPDATE `document_request_master` SET `isUploaded`="1" WHERE id=' + fileData.requestId);

                    res
                        .status(200)
                        .json({
                            success: true,
                            data: {
                                url: './uploads/' + filePath,
                                name: fileData.fileName
                            },
                        });
                });
        } else
            return res
                .status(400)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
    } catch (error) {
        return res
            .status(400)
            .json({
                success: false,
                error: "Something went wrong: " + error,
            });
    }

});

module.exports = router;