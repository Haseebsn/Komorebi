const express = require('express');
const mysql = require('mysql2');
const session = require('express-session');
const path = require('path');
const jwt = require("jsonwebtoken");
var router = express.Router();

var connection = require('./connection')

router.post('/', function (req, res, next) {

  const user = req.body;

  connection.query(
    'SELECT * FROM `users` WHERE username=?', [user.username],
    function (err, results, fields) {
      if (results.length > 0)
        return res
          .status(200)
          .json({
            success: false,
            error: "User already exists",
          });

      var user = req.body;
      var sql = `INSERT INTO users (name, username, password, email, category, orgId, createdBy, updatedBy) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
      var values = [user.name, user.username, user.password, user.email, user.category, user.orgId, user.createdBy, user.updatedBy];

      connection.query(sql, values, function (err, result) {
        if (err) {
          return res
            .status(200)
            .json({
              success: false,
              error: "Something went wrong: " + err,
            });
        };
        console.log("Number of records inserted: " + result.affectedRows);

        if (result.affectedRows > 0) {
          const userToken = {};
          user.id = result.insertId;
          userToken.username = user.username;
          userToken.id = user.id;
          userToken.category = user.category;
          userToken.email = user.email;

          let token;
          try {
            //Creating jwt token
            token = jwt.sign(
              { userId: user.id, userData: userToken },
              "venture",
              { expiresIn: "1h" }
            );
          } catch (err) {
            console.log(err);
            const error = new Error("Error! Something went wrong.");
            return next(error);
          }

          res
            .status(200)
            .json({
              success: true,
              data: {
                userId: user.id,
                token: token,
              },
            });
        } else
          return res
            .status(200)
            .json({
              success: false,
              error: "Something went wrong",
            });
      });

    });
});

module.exports = router;