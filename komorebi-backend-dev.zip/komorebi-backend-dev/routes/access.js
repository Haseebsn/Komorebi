var express = require('express');
var connection = require('./connection');
var router = express.Router();

router.get('/', function (req, res, next) {

    const user = req.query.i;

    var sql = 'SELECT `access_master`.`accessOf` FROM `users` LEFT JOIN `access_master` ON `users`.`id`=`access_master`.`userId` WHERE `users`.`id`=?';
    var values = [user];

    connection.query(sql, values, function (err, result) {
        if (err) {
            return res
                .status(200)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        }
        console.log("Fetched records: " + result.length);

        sql = 'SELECT `users`.`twoFactAuth` FROM `users` WHERE `users`.`id`=?';
        values = [user];

        connection.query(sql, values, function (err, factResult) {
            if (err) {
                return res
                    .status(200)
                    .json({
                        success: false,
                        error: "Something went wrong: " + err,
                    });
            }
            console.log("Fetched records: " + factResult.length);

            result.push(factResult[0]);

            res
                .status(200)
                .json({
                    success: true,
                    data: result,
                });
        });

    });

});

router.post('/', function (req, res, next) {
    userDetails = req.body;
    userAccess = userDetails.access;
    twoFactAuth = userDetails.twoFactAuth;

    let sql = "UPDATE `users` SET `twoFactAuth`=?, updatedBy=? WHERE `id`=?";
    let values = [twoFactAuth ? "1" : "0", userDetails.updatedBy, userDetails.id];

    connection.query(sql, values, function (err, result) {
        if (err) {
            return res
                .status(500)
                .json({
                    success: false,
                    error: "Something went wrong: " + err,
                });
        }
        console.log("Two factor updated: " + result.affectedRows);
    });

    connection.query(
        'SELECT * FROM `access_master` WHERE userId=?', [userDetails.id],
        function (err, results, fields) {
            if (err) {
                return res
                    .status(200)
                    .json({
                        success: false,
                        error: "Something went wrong: " + err,
                    });
            };

            let removedAccess = []
            let existingAccess = []
            let newAccess = [];

            if (results.length > 0) {
                results.forEach(access => {
                    existingAccess.push(Number(access.accessOf));

                    if (!userAccess.includes(Number(access.accessOf))) {
                        removedAccess.push(access.accessOf);
                    }
                });

                if (removedAccess.length > 0) {
                    let sql = "UPDATE `access_master` SET `enabled`='0', updatedBy=? WHERE `userId`=? AND `accessOf` IN (?)";
                    let values = [userDetails.updatedBy, userDetails.id, removedAccess];

                    connection.query(sql, values, function (err, result) {
                        if (err) {
                            return res
                                .status(500)
                                .json({
                                    success: false,
                                    error: "Something went wrong: " + err,
                                });
                        }
                        console.log("Number of records updated: " + result.affectedRows);

                        newAccess = userAccess.filter(o => !existingAccess.includes(o));

                        newAccess.forEach(na => {
                            var sql = `INSERT INTO access_master (userId, accessOf, createdBy, updatedBy) VALUES (?, ?, ?, ?)`;
                            var values = [userDetails.id, na, userDetails.updatedBy, userDetails.updatedBy];

                            connection.query(sql, values, function (err, result) {
                                if (err) {
                                    return res
                                        .status(200)
                                        .json({
                                            success: false,
                                            error: "Something went wrong: " + err,
                                        });
                                };
                                console.log("Number of records inserted: " + result.affectedRows);

                                if (result.affectedRows > 0) {
                                    return res
                                        .status(200)
                                        .json({
                                            success: true,
                                            data: result,
                                        });
                                }
                            });
                        });
                    });
                } else {
                    newAccess = userAccess.filter(o => !existingAccess.includes(o));

                    if (newAccess.length > 0)
                        newAccess.forEach(na => {
                            var sql = `INSERT INTO access_master (userId, accessOf, createdBy, updatedBy) VALUES (?, ?, ?, ?)`;
                            var values = [userDetails.id, na, userDetails.updatedBy, userDetails.updatedBy];

                            connection.query(sql, values, function (err, result) {
                                if (err) {
                                    return res
                                        .status(200)
                                        .json({
                                            success: false,
                                            error: "Something went wrong: " + err,
                                        });
                                };
                                console.log("Number of records inserted: " + result.affectedRows);

                                if (result.affectedRows > 0) {
                                    return res
                                        .status(200)
                                        .json({
                                            success: true,
                                            data: result,
                                        });
                                }
                            });
                        });
                    else
                        return res
                            .status(200)
                            .json({
                                success: true
                            });
                }
            } else {
                userAccess.forEach(na => {
                    var sql = `INSERT INTO access_master (userId, accessOf, createdBy, updatedBy) VALUES (?, ?, ?, ?)`;
                    var values = [userDetails.id, na, userDetails.updatedBy, userDetails.updatedBy];

                    connection.query(sql, values, function (err, result) {
                        if (err) {
                            return res
                                .status(200)
                                .json({
                                    success: false,
                                    error: "Something went wrong: " + err,
                                });
                        };
                        console.log("Number of records inserted: " + result.affectedRows);

                        if (result.affectedRows > 0) {
                            return res
                                .status(200)
                                .json({
                                    success: true,
                                    data: result,
                                });
                        }
                    });
                });
            }
        });
});

module.exports = router;