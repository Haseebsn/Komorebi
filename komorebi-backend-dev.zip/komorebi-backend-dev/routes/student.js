var express = require('express');
var connection = require('./connection');
var router = express.Router();

router.get('/', function (req, res, next) {

    const orgId = req.query.orgId;

    // simple query
    connection.query(
        'SELECT * FROM `users` WHERE enabled="1" AND category="student" AND orgId=' + orgId,
        function (err, results, fields) {
            console.log(results);

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.get('/fetchAll', function (req, res, next) {

    const orgId = req.query.orgId;

    // simple query
    connection.query(
        'SELECT * FROM `users` WHERE category="student"',
        function (err, results, fields) {
            console.log(results);

            res
                .status(200)
                .json({
                    success: true,
                    data: results,
                });
        });
});

router.get('/fetchCount', function (req, res, next) {

    const user = req.body;

    // simple query
    connection.query(
        'SELECT COUNT(category) AS stdcount FROM `users` WHERE enabled="1" AND category="student"',
        function (err, results, fields) {
            console.log(results[0]);

            res
                .status(200)
                .json({
                    success: true,
                    data: results[0],
                });
        });
});

module.exports = router;