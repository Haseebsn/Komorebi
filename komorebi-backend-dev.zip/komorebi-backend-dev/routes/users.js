var express = require('express');
var connection = require('./connection');
var router = express.Router();
const nodemailer = require('nodemailer');

router.post('/update', function (req, res, next) {

  const user = req.body;

  var sql = 'UPDATE `users` SET  name=?, email=?, updatedBy=? WHERE id=?';
  var values = [user.name, user.email, user.updatedBy, user.id];

  connection.query(sql, values, function (err, result) {
    if (err) {
      return res
        .status(200)
        .json({
          success: false,
          error: "Something went wrong: " + err,
        });
    };
    console.log("Number of records inserted: " + result.affectedRows);

    res
      .status(200)
      .json({
        success: true,
        data: result,
      });
  });

});

router.get('/delete', function (req, res, next) {

  const id = req.query.id;

  // simple query
  connection.query(
    'UPDATE `users` SET enabled="0" WHERE id=' + id,
    function (err, results, fields) {
      console.log(results);

      if (results.affectedRows == 1) {
        res
          .status(200)
          .json({
            success: true,
            data: "Deleted Successfully",
          });
      }
    });
});

router.get('/id', function (req, res, next) {

  const id = req.query.id;
  // simple query
  connection.query(
    'SELECT * FROM `users` WHERE id=' + id,
    function (err, results, fields) {
      console.log(results);

      res
        .status(200)
        .json({
          success: true,
          data: results,
        });
    });
});

router.post('/verify', function (req, res, next) {

  const user = req.body.username;

  const query = 'SELECT * FROM `users` WHERE username="' + user + '"';

  connection.query(query, function (err, results, fields) {
    if (err) {
      console.log(err);
      return res
        .status(200)
        .json({
          success: false,
          error: "Something went wrong: " + err,
        });
    }

    console.log(results);

    if (results.length > 0) {
      let code = userCodeGenerator();

      const transporter = nodemailer.createTransport({
        port: 465,               // true for 465, false for other ports
        host: "smtp.gmail.com",
        auth: {
          user: 'shahrukhzaman256@gmail.com',
          pass: 'znszedtwblqolrao',
        },
        secure: true,
      });

      const mailData = {
        from: 'shahrozximtiaz@gmail.com',  // sender address
        to: results[0].email,   // list of receivers
        subject: 'OTP for two-fact authentication',
        html: '<b>OTP for Komorebi: </b> ' + code
      };

      transporter.sendMail(mailData, function (err, info) {
        if (err) {
          console.log(err)
          res
            .status(400)
            .json({
              success: false,
              data: {
                error: err
              },
            });
        }
        else {
          console.log(info);

          connection.query("INSERT INTO `authentication_master` (otp, type, validUpto, createdBy) VALUES (?, ?, ?, ?)", [code, '0', new Date(new Date().getTime() + 5 * 60000), results[0].id], function (err, factResult) {
            if (err) {
              return res
                .status(200)
                .json({
                  success: false,
                  error: "Something went wrong: " + err,
                });
            }
            console.log("Inserted records in auth master: " + factResult.length);
          });
        }
      });

      res
        .status(200)
        .json({
          success: true,
          data: results,
        });
    }
    else
      return res
        .status(200)
        .json({
          success: false,
          error: "Username not found",
        });
  });
});

function userCodeGenerator() {
  var chars = '1234567890',
    serialLength = 4,
    randomSerial = "",
    i,
    randomNumber;

  for (i = 0; i < serialLength; i = i + 1) {
    randomNumber = Math.floor(Math.random() * chars.length);
    randomSerial += chars.substring(randomNumber, randomNumber + 1);
  }

  return randomSerial;
}

module.exports = router;