const express = require('express');

var router = express.Router();

var connection = require('./connection')
router.get('/otp', function (req, res, next) {

    const otp = req.query.otp;
    const userId = req.query.id;

    // simple query
    connection.query(
        'SELECT * FROM `authentication_master` WHERE otp=?', [otp, userId],
        function (err, results, fields) {
            console.log(results[0]);
            if (results.length == 0) {
                return res
                    .status(200)
                    .json({
                        success: false,
                        error: "OTP not valid",
                    });
            }

            console.log("OTP validated");

            res
                .status(200)
                .json({
                    success: true
                });
        }
    );

});

module.exports = router;